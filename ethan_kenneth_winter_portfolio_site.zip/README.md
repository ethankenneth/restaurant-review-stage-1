#Udacity Front-End Web Development Nanodegree Project Build a Portfolio Site

By Ethan Kenneth Winter
2018


##What Is This?

This is a portfolio site built using HTML and CSS based on the Udacity guidelines.


##How do I use this?

You'll need a text editor, such as Atom or Sublime. You'll also need a web browser, like Chrome, or Firefox.
If you open the index.html file in you web browser (ctrl+o), you can see the page itself.
If you open the files in your text editor, you can change the html or css.


##What's here?

You're already reading the README file, so good start!
The index.html is linked to two css files, style.css and responsive.css.
Also, contained in the img folder, are all the images you'll see on the index.html when opened in your browswer.
